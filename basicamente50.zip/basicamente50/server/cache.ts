import memoize from "memoizee";

// Cache metrics with 5 minute TTL
export const cacheMetrics = memoize(
  async (organizationId: string, getMetrics: Function) => {
    return await getMetrics(organizationId);
  },
  {
    maxAge: 5 * 60 * 1000,
    promise: true,
    normalizer: (args) => args[0],
  }
);

// Cache categories with 10 minute TTL
export const cacheCategories = memoize(
  async (organizationId: string, getCategories: Function) => {
    return await getCategories(organizationId);
  },
  {
    maxAge: 10 * 60 * 1000,
    promise: true,
    normalizer: (args) => args[0],
  }
);

// Cache user preferences with 15 minute TTL
export const cacheUserPreferences = memoize(
  async (userId: string, getPreferences: Function) => {
    return await getPreferences(userId);
  },
  {
    maxAge: 15 * 60 * 1000,
    promise: true,
    normalizer: (args) => args[0],
  }
);

// Cache bank accounts with 10 minute TTL
export const cacheBankAccounts = memoize(
  async (organizationId: string, getBankAccounts: Function) => {
    return await getBankAccounts(organizationId);
  },
  {
    maxAge: 10 * 60 * 1000,
    promise: true,
    normalizer: (args) => args[0],
  }
);

// Cache cost centers with 10 minute TTL
export const cacheCostCenters = memoize(
  async (organizationId: string, getCostCenters: Function) => {
    return await getCostCenters(organizationId);
  },
  {
    maxAge: 10 * 60 * 1000,
    promise: true,
    normalizer: (args) => args[0],
  }
);

// Cache tags with 10 minute TTL
export const cacheTags = memoize(
  async (organizationId: string, getTags: Function) => {
    return await getTags(organizationId);
  },
  {
    maxAge: 10 * 60 * 1000,
    promise: true,
    normalizer: (args) => args[0],
  }
);

// Clear all caches
export function clearCache(fn?: any) {
  if (fn && typeof fn.clear === 'function') {
    fn.clear();
  } else {
    (cacheMetrics as any).clear();
    (cacheCategories as any).clear();
    (cacheUserPreferences as any).clear();
    (cacheBankAccounts as any).clear();
    (cacheCostCenters as any).clear();
    (cacheTags as any).clear();
  }
}
