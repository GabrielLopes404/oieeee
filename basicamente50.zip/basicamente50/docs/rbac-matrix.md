# Matriz de Controle de Acesso Baseado em Funções (RBAC)

## Visão Geral

O sistema LUCREI implementa controle de acesso granular com 3 níveis de permissão:

- **OWNER**: Proprietário da organização (1 por organização)
- **ADMIN**: Administrador com permissões amplas
- **CUSTOMER**: Cliente/usuário comum com permissões limitadas

---

## Matriz Completa de Permissões

### Gestão de Organização

| Ação | OWNER | ADMIN | CUSTOMER | Endpoint/Função |
|------|-------|-------|----------|-----------------|
| Criar organização | ✅ | ❌ | ❌ | `POST /api/organizations` |
| Ver dados da organização | ✅ | ✅ | ✅ | `GET /api/organizations/:id` |
| Editar organização | ✅ | ❌ | ❌ | `PUT /api/organizations/:id` |
| Excluir organização | ✅ | ❌ | ❌ | `DELETE /api/organizations/:id` |
| Transferir ownership | ✅ | ❌ | ❌ | `POST /api/organizations/:id/transfer` |

---

### Gestão de Usuários

| Ação | OWNER | ADMIN | CUSTOMER | Endpoint/Função |
|------|-------|-------|----------|-----------------|
| Convidar usuários | ✅ | ✅ | ❌ | `POST /api/users/invite` |
| Listar usuários da org | ✅ | ✅ | ❌ | `GET /api/users` |
| Ver perfil próprio | ✅ | ✅ | ✅ | `GET /api/user` |
| Editar perfil próprio | ✅ | ✅ | ✅ | `PUT /api/user` |
| Editar outros usuários | ✅ | ✅ | ❌ | `PUT /api/users/:id` |
| Promover para ADMIN | ✅ | ❌ | ❌ | `POST /api/users/:id/promote` |
| Rebaixar para CUSTOMER | ✅ | ❌ | ❌ | `POST /api/users/:id/demote` |
| Remover usuário | ✅ | ✅ | ❌ | `DELETE /api/users/:id` |

---

### Transações Financeiras

| Ação | OWNER | ADMIN | CUSTOMER | Escopo |
|------|-------|-------|----------|---------|
| Criar transação | ✅ | ✅ | ✅ | Todas / Todas / Só suas |
| Listar transações | ✅ | ✅ | ✅ | Todas / Todas / Só suas |
| Ver detalhes de transação | ✅ | ✅ | ✅* | Todas / Todas / Só suas |
| Editar transação | ✅ | ✅ | ✅* | Todas / Todas / Só suas |
| Excluir transação | ✅ | ✅ | ❌ | Todas / Todas / - |
| Importar transações (OFX/CSV) | ✅ | ✅ | ❌ | - |
| Exportar transações | ✅ | ✅ | ❌ | - |
| Reconciliar transações | ✅ | ✅ | ❌ | - |

\* CUSTOMER só pode acessar/editar transações criadas por ele

---

### Faturas (Invoices)

| Ação | OWNER | ADMIN | CUSTOMER | Escopo |
|------|-------|-------|----------|---------|
| Criar fatura | ✅ | ✅ | ❌ | - |
| Listar faturas | ✅ | ✅ | ✅ | Todas / Todas / Só suas |
| Ver detalhes de fatura | ✅ | ✅ | ✅* | Todas / Todas / Só suas |
| Editar fatura | ✅ | ✅ | ❌ | - |
| Excluir fatura | ✅ | ✅ | ❌ | - |
| Gerar PDF de fatura | ✅ | ✅ | ✅* | Todas / Todas / Só suas |
| Enviar fatura por email | ✅ | ✅ | ❌ | - |
| Marcar como paga | ✅ | ✅ | ❌ | - |

\* CUSTOMER só pode ver faturas endereçadas a ele

---

### Clientes (Customers)

| Ação | OWNER | ADMIN | CUSTOMER | Endpoint |
|------|-------|-------|----------|----------|
| Criar cliente | ✅ | ✅ | ❌ | `POST /api/customers` |
| Listar clientes | ✅ | ✅ | ❌ | `GET /api/customers` |
| Ver detalhes do cliente | ✅ | ✅ | ❌ | `GET /api/customers/:id` |
| Editar cliente | ✅ | ✅ | ❌ | `PUT /api/customers/:id` |
| Excluir cliente | ✅ | ✅ | ❌ | `DELETE /api/customers/:id` |

---

### Contas Bancárias

| Ação | OWNER | ADMIN | CUSTOMER | Endpoint |
|------|-------|-------|----------|----------|
| Adicionar conta bancária | ✅ | ✅ | ❌ | `POST /api/bank-accounts` |
| Listar contas bancárias | ✅ | ✅ | ✅ (view-only) | `GET /api/bank-accounts` |
| Ver saldo/extrato | ✅ | ✅ | ✅ (view-only) | `GET /api/bank-accounts/:id` |
| Editar conta bancária | ✅ | ✅ | ❌ | `PUT /api/bank-accounts/:id` |
| Remover conta bancária | ✅ | ✅ | ❌ | `DELETE /api/bank-accounts/:id` |

---

### Categorias e Tags

| Ação | OWNER | ADMIN | CUSTOMER | Endpoint |
|------|-------|-------|----------|----------|
| Criar categoria | ✅ | ✅ | ❌ | `POST /api/categories` |
| Listar categorias | ✅ | ✅ | ✅ | `GET /api/categories` |
| Editar categoria | ✅ | ✅ | ❌ | `PUT /api/categories/:id` |
| Excluir categoria | ✅ | ✅ | ❌ | `DELETE /api/categories/:id` |
| Criar tag | ✅ | ✅ | ❌ | `POST /api/tags` |
| Listar tags | ✅ | ✅ | ✅ | `GET /api/tags` |
| Editar tag | ✅ | ✅ | ❌ | `PUT /api/tags/:id` |
| Excluir tag | ✅ | ✅ | ❌ | `DELETE /api/tags/:id` |

---

### Centros de Custo

| Ação | OWNER | ADMIN | CUSTOMER | Endpoint |
|------|-------|-------|----------|----------|
| Criar centro de custo | ✅ | ✅ | ❌ | `POST /api/cost-centers` |
| Listar centros de custo | ✅ | ✅ | ✅ (view-only) | `GET /api/cost-centers` |
| Editar centro de custo | ✅ | ✅ | ❌ | `PUT /api/cost-centers/:id` |
| Excluir centro de custo | ✅ | ✅ | ❌ | `DELETE /api/cost-centers/:id` |

---

### Relatórios e Analytics

| Ação | OWNER | ADMIN | CUSTOMER | Escopo |
|------|-------|-------|----------|---------|
| Dashboard financeiro | ✅ | ✅ | ✅ | Completo / Completo / Limitado |
| Gerar relatórios | ✅ | ✅ | ❌ | - |
| Exportar relatórios (PDF/CSV) | ✅ | ✅ | ❌ | - |
| Ver métricas de negócio | ✅ | ✅ | ❌ | - |
| Análise de fluxo de caixa | ✅ | ✅ | ❌ | - |
| Projeções financeiras | ✅ | ✅ | ❌ | - |

**Dashboard CUSTOMER:** Vê apenas suas próprias transações e faturas

---

### Assinaturas e Pagamentos (Stripe)

| Ação | OWNER | ADMIN | CUSTOMER | Endpoint |
|------|-------|-------|----------|----------|
| Ver plano atual | ✅ | ✅ | ✅ (view-only) | `GET /api/subscription` |
| Criar assinatura | ✅ | ❌ | ❌ | `POST /api/stripe/checkout` |
| Alterar plano | ✅ | ❌ | ❌ | `POST /api/subscription/change` |
| Cancelar assinatura | ✅ | ❌ | ❌ | `POST /api/subscription/cancel` |
| Ver histórico de pagamentos | ✅ | ✅ | ❌ | `GET /api/subscription/invoices` |
| Atualizar método de pagamento | ✅ | ❌ | ❌ | `POST /api/subscription/payment-method` |

---

### Configurações do Sistema

| Ação | OWNER | ADMIN | CUSTOMER | Endpoint |
|------|-------|-------|----------|----------|
| Configurar integrações | ✅ | ❌ | ❌ | `PUT /api/settings/integrations` |
| Configurar emails | ✅ | ✅ | ❌ | `PUT /api/settings/emails` |
| Ver logs de auditoria | ✅ | ✅ | ❌ | `GET /api/audit-logs` |
| Configurar webhooks | ✅ | ❌ | ❌ | `POST /api/webhooks` |
| Gerenciar API keys | ✅ | ❌ | ❌ | `POST /api/api-keys` |

---

### Documentos e Arquivos

| Ação | OWNER | ADMIN | CUSTOMER | Endpoint |
|------|-------|-------|----------|----------|
| Upload de documentos | ✅ | ✅ | ✅ | `POST /api/documents` |
| Listar documentos | ✅ | ✅ | ✅* | `GET /api/documents` |
| Download de documentos | ✅ | ✅ | ✅* | `GET /api/documents/:id/download` |
| Excluir documentos | ✅ | ✅ | ✅* | `DELETE /api/documents/:id` |

\* CUSTOMER só pode acessar documentos próprios

---

## Implementação no Código

### Middleware de Autorização

```typescript
// server/auth-middleware.ts
export function requireRole(...roles: Role[]) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: "Não autenticado" });
    }
    
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ 
        error: "Acesso negado",
        required: roles,
        current: req.user.role
      });
    }
    
    next();
  };
}

// Uso nos endpoints
app.post('/api/customers', 
  requireAuth,
  requireRole('OWNER', 'ADMIN'),
  createCustomer
);
```

### Filtro de Query Automático

```typescript
// server/db-utils.ts
export function addOrganizationFilter(query, user) {
  // Sempre filtra por organização
  query.where('organization_id', user.organizationId);
  
  // Se CUSTOMER, filtra apenas dados próprios
  if (user.role === 'CUSTOMER') {
    query.where('user_id', user.id);
  }
  
  return query;
}

// Uso
const transactions = await db
  .select()
  .from(transactionsTable)
  .then(query => addOrganizationFilter(query, req.user));
```

---

## Casos de Uso

### Caso 1: Empresa Pequena (1-5 pessoas)

```
Owner (João) ─── cria organização
      │
      ├─── Convida Admin (Maria) ─── gerencia transações
      └─── Convida Customer (Pedro) ─── registra despesas próprias
```

**Configuração:**
- João: OWNER (gerencia tudo + pagamentos)
- Maria: ADMIN (operações diárias)
- Pedro: CUSTOMER (apenas suas despesas)

---

### Caso 2: Empresa Média (10-50 pessoas)

```
Owner (CEO) ─── configura sistema + pagamentos
      │
      ├─── Admin (CFO) ─── relatórios financeiros
      ├─── Admin (Contador) ─── reconciliação
      │
      ├─── Customer (Vendedor 1) ─── despesas de viagem
      ├─── Customer (Vendedor 2) ─── despesas de viagem
      └─── ... (outros funcionários)
```

**Configuração:**
- 1 OWNER (gestão estratégica)
- 2-3 ADMINs (operações financeiras)
- 10-47 CUSTOMERs (usuários finais)

---

## Auditoria de Permissões

### Logs Automáticos

Todas as ações críticas são registradas:

```typescript
// server/audit-log.ts
export async function logAction(
  userId: string,
  action: string,
  resource: string,
  resourceId: string,
  success: boolean
) {
  await db.insert(auditLogs).values({
    userId,
    action,
    resource,
    resourceId,
    success,
    timestamp: new Date(),
    ipAddress: req.ip,
    userAgent: req.headers['user-agent']
  });
}
```

**Exemplos de logs:**
- `user_123 -> DELETE transaction_456 -> SUCCESS`
- `user_789 -> UPDATE customer_321 -> DENIED (role: CUSTOMER)`

---

## Testes de RBAC

### Matriz de Testes

```typescript
describe('RBAC - Transactions', () => {
  it('OWNER pode criar transação de qualquer usuário', async () => {
    const res = await request(app)
      .post('/api/transactions')
      .set('Cookie', ownerCookie)
      .send({ userId: 'other-user', amount: 100 });
    
    expect(res.status).toBe(201);
  });
  
  it('CUSTOMER não pode criar transação de outro usuário', async () => {
    const res = await request(app)
      .post('/api/transactions')
      .set('Cookie', customerCookie)
      .send({ userId: 'other-user', amount: 100 });
    
    expect(res.status).toBe(403);
  });
  
  it('ADMIN pode deletar transação', async () => {
    const res = await request(app)
      .delete('/api/transactions/123')
      .set('Cookie', adminCookie);
    
    expect(res.status).toBe(200);
  });
  
  it('CUSTOMER não pode deletar transação', async () => {
    const res = await request(app)
      .delete('/api/transactions/123')
      .set('Cookie', customerCookie);
    
    expect(res.status).toBe(403);
  });
});
```

---

## Escalação de Privilégios (Prevenção)

### Proteções Implementadas

1. **Não pode promover a si mesmo**
```typescript
if (req.params.userId === req.user.id) {
  return res.status(403).json({ error: "Não pode alterar próprio role" });
}
```

2. **Apenas OWNER pode promover para ADMIN**
```typescript
if (newRole === 'ADMIN' && req.user.role !== 'OWNER') {
  return res.status(403).json({ error: "Apenas OWNER pode promover para ADMIN" });
}
```

3. **Não pode alterar OWNER de outra organização**
```typescript
if (targetUser.organizationId !== req.user.organizationId) {
  return res.status(403).json({ error: "Organizações diferentes" });
}
```

---

## Suporte Multi-Organização

### Isolamento Completo

Cada organização é completamente isolada:

```typescript
// Middleware global
app.use((req, res, next) => {
  if (req.user) {
    // Injeta organizationId em todas as queries
    req.organizationId = req.user.organizationId;
  }
  next();
});

// Todas as queries automaticamente filtram
SELECT * FROM transactions 
WHERE organization_id = $1; -- Sempre presente
```

**Impossível:**
- OWNER da Org A ver dados da Org B
- ADMIN da Org A editar usuário da Org B
- CUSTOMER da Org A ver transações da Org B

---

## Mudanças Futuras (Roadmap)

### Roles Customizadas (v2.0)

```typescript
// Futuro: roles personalizadas
{
  name: "Assistente Financeiro",
  permissions: [
    "transactions.create",
    "transactions.read",
    "invoices.read",
    "reports.read"
  ]
}
```

### Permissões Granulares (v2.5)

```typescript
// Futuro: permissões por recurso
{
  resource: "transactions",
  actions: ["create", "read"],
  conditions: {
    "amount": { "lessThan": 1000 },
    "type": { "equals": "expense" }
  }
}
```

---

**Última Atualização:** 04 de Novembro de 2025  
**Versão:** 1.0  
**Próxima Revisão:** Trimestral
