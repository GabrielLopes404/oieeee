import * as Sentry from "@sentry/react";

export function initSentry() {
  const sentryDsn = import.meta.env.VITE_SENTRY_DSN;
  
  if (!sentryDsn) {
    console.warn('SENTRY_DSN not configured. Error tracking disabled.');
    return;
  }

  Sentry.init({
    dsn: sentryDsn,
    environment: import.meta.env.MODE || 'development',
    
    // Performance Monitoring
    integrations: [
      Sentry.browserTracingIntegration(),
      Sentry.replayIntegration({
        maskAllText: true,
        blockAllMedia: true,
      }),
    ],
    
    // Performance Monitoring sample rates
    tracesSampleRate: import.meta.env.MODE === 'production' ? 0.1 : 1.0,
    
    // Session Replay sample rates
    replaysSessionSampleRate: 0.1, // Sample 10% of sessions
    replaysOnErrorSampleRate: 1.0, // Sample 100% of sessions with errors
    
    // BeforeSend hook to sanitize sensitive data
    beforeSend(event, hint) {
      // Remove sensitive form data
      if (event.request?.data) {
        const data = event.request.data as any;
        if (typeof data === 'object' && data !== null) {
          delete data.password;
          delete data.newPassword;
          delete data.currentPassword;
          delete data.confirmPassword;
          delete data.apiKey;
          delete data.token;
        }
      }
      
      return event;
    },
    
    // Ignore certain errors
    ignoreErrors: [
      'ResizeObserver loop limit exceeded',
      'Non-Error promise rejection captured',
      'NetworkError',
      'Failed to fetch',
      'Network request failed',
      'Load failed',
      'AbortError',
      // Browser extensions
      'chrome-extension://',
      'moz-extension://',
    ],
  });

  console.log(`Sentry initialized for ${import.meta.env.MODE} environment`);
}

export { Sentry };
