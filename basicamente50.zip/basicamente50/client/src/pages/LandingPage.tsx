import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  ArrowRight, 
  Check, 
  TrendingUp, 
  Shield, 
  BarChart3, 
  Zap, 
  Globe, 
  Users, 
  ChevronRight,
  Menu,
  X,
  Star
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function LandingPage() {
  const [, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const features = [
    {
      icon: TrendingUp,
      title: "Análise em Tempo Real",
      description: "Monitore seu fluxo de caixa e métricas financeiras em tempo real com dashboards intuitivos."
    },
    {
      icon: Shield,
      title: "Segurança Empresarial",
      description: "Criptografia de ponta a ponta e conformidade com LGPD para proteção total dos seus dados."
    },
    {
      icon: BarChart3,
      title: "Relatórios Avançados",
      description: "Gere relatórios personalizados e tome decisões baseadas em dados concretos."
    },
    {
      icon: Zap,
      title: "Automação Inteligente",
      description: "Automatize processos repetitivos e economize horas de trabalho manual."
    },
    {
      icon: Globe,
      title: "Acesso em Qualquer Lugar",
      description: "Plataforma em nuvem acessível de qualquer dispositivo, a qualquer momento."
    },
    {
      icon: Users,
      title: "Gestão de Equipes",
      description: "Controle de permissões e colaboração em tempo real para toda sua equipe."
    }
  ];

  const testimonials = [
    {
      name: "Ana Silva",
      role: "CFO, TechCorp",
      content: "O LUCREI transformou completamente nossa gestão financeira. Conseguimos reduzir custos em 35% no primeiro trimestre.",
      rating: 5
    },
    {
      name: "Carlos Mendes",
      role: "Diretor Financeiro, StartupXYZ",
      content: "Interface intuitiva e poderosa. Nossa equipe adotou a plataforma em menos de uma semana.",
      rating: 5
    },
    {
      name: "Mariana Costa",
      role: "CEO, InovaSolutions",
      content: "Relatórios precisos e automação que nos economiza mais de 100 horas por mês. Recomendo fortemente.",
      rating: 5
    }
  ];

  const plans = [
    {
      name: "Starter",
      price: "R$ 97",
      period: "/mês",
      description: "Perfeito para pequenas empresas",
      features: [
        "Até 5 usuários",
        "100 transações/mês",
        "Relatórios básicos",
        "Suporte por email",
        "Integrações essenciais"
      ],
      highlighted: false
    },
    {
      name: "Professional",
      price: "R$ 297",
      period: "/mês",
      description: "Ideal para empresas em crescimento",
      features: [
        "Usuários ilimitados",
        "Transações ilimitadas",
        "Relatórios avançados",
        "Suporte prioritário 24/7",
        "Todas as integrações",
        "API completa",
        "Treinamento dedicado"
      ],
      highlighted: true
    },
    {
      name: "Enterprise",
      price: "Personalizado",
      period: "",
      description: "Solução sob medida",
      features: [
        "Tudo do Professional",
        "Gerente de conta dedicado",
        "SLA garantido",
        "Implementação personalizada",
        "Consultoria estratégica",
        "Infraestrutura dedicada"
      ],
      highlighted: false
    }
  ];

  return (
    <div className="dark min-h-screen bg-background text-foreground">
      {/* Header */}
      <motion.header 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled 
            ? 'bg-background/95 backdrop-blur-xl border-b shadow-sm' 
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <motion.div 
              className="text-2xl font-bold"
              whileHover={{ scale: 1.02 }}
            >
              <span className="bg-gradient-to-r from-purple-600 to-violet-600 bg-clip-text text-transparent">
                LUCREI
              </span>
            </motion.div>

            <nav className="hidden md:flex items-center gap-8">
              {['Recursos', 'Preços', 'Depoimentos'].map((item) => (
                <a 
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                >
                  {item}
                </a>
              ))}
            </nav>

            <div className="hidden md:flex items-center gap-4">
              <Button 
                variant="ghost" 
                onClick={() => setLocation('/login')}
              >
                Entrar
              </Button>
              <Button 
                onClick={() => setLocation('/register')}
                className="bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-700 hover:to-violet-700"
              >
                Começar Agora
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>

            <button
              className="md:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden border-t bg-background/95 backdrop-blur-xl"
            >
              <nav className="flex flex-col p-4 gap-4">
                {['Recursos', 'Preços', 'Depoimentos'].map((item) => (
                  <a 
                    key={item}
                    href={`#${item.toLowerCase()}`}
                    className="text-sm font-medium py-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {item}
                  </a>
                ))}
                <div className="flex flex-col gap-2 pt-2 border-t">
                  <Button 
                    variant="ghost" 
                    onClick={() => setLocation('/login')}
                  >
                    Entrar
                  </Button>
                  <Button 
                    onClick={() => setLocation('/register')}
                    className="bg-gradient-to-r from-purple-600 to-violet-600"
                  >
                    Começar Agora
                  </Button>
                </div>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.header>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Animated background gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-background to-background" />
        <div className="absolute inset-0">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '4s' }} />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-violet-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '6s', animationDelay: '1s' }} />
        </div>
        
        <div className="max-w-7xl mx-auto relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
              className="space-y-8"
            >
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-primary/10 to-violet-500/10 border border-purple-500/20 text-foreground text-sm font-medium"
              >
                <Shield className="h-4 w-4 text-primary" />
                <span>Confiado por mais de 5.000 empresas</span>
              </motion.div>

              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.3 }}
                className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight"
              >
                Gestão financeira{" "}
                <span className="bg-gradient-to-r from-primary via-violet-500 to-primary bg-clip-text text-transparent animate-gradient bg-[length:200%_auto]">
                  profissional
                </span>
                {" "}para sua empresa
              </motion.h1>

              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="text-xl text-muted-foreground leading-relaxed"
              >
                Plataforma completa de gestão financeira que oferece controle total sobre suas finanças, 
                com análises em tempo real e automação inteligente.
              </motion.p>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
                className="flex flex-col sm:flex-row gap-4"
              >
                <Button 
                  size="lg"
                  onClick={() => setLocation('/register')}
                  className="bg-gradient-to-r from-primary to-violet-500 hover:from-primary/90 hover:to-violet-600 text-lg px-8 shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all duration-300 hover:scale-105"
                >
                  Começar Teste Gratuito
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button 
                  size="lg"
                  variant="outline"
                  className="text-lg px-8 border-2 hover:bg-primary/5 transition-all duration-300"
                >
                  Agendar Demonstração
                </Button>
              </motion.div>

              <div className="flex items-center gap-8 pt-4">
                <div className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-purple-600" />
                  <span className="text-sm text-muted-foreground">Sem cartão de crédito</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-purple-600" />
                  <span className="text-sm text-muted-foreground">7 dias grátis</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-5 w-5 text-purple-600" />
                  <span className="text-sm text-muted-foreground">Cancele quando quiser</span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
              className="relative"
            >
              <div className="absolute -inset-6 bg-gradient-to-r from-primary/30 via-violet-500/30 to-primary/30 rounded-3xl blur-3xl opacity-75 animate-pulse" style={{ animationDuration: '3s' }} />
              <motion.div 
                className="relative rounded-2xl border-2 border-purple-500/20 bg-card/80 backdrop-blur-xl p-6 sm:p-8 shadow-2xl shadow-primary/10"
                whileHover={{ scale: 1.02, boxShadow: "0 25px 50px -12px rgba(59, 130, 246, 0.25)" }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
              >
                <div className="space-y-6">
                  <div className="flex items-center justify-between pb-4 border-b border-border/50">
                    <span className="text-sm font-medium text-muted-foreground">Dashboard Overview</span>
                    <div className="h-8 w-8 rounded-full bg-gradient-to-r from-primary to-violet-500 shadow-lg shadow-primary/50" />
                  </div>
                  <div className="grid grid-cols-3 gap-2 sm:gap-4">
                    {[
                      { label: "Receita", value: "R$ 142.5K", change: "+12.5%", positive: true },
                      { label: "Despesas", value: "R$ 89.2K", change: "-3.2%", positive: false },
                      { label: "Lucro", value: "R$ 53.3K", change: "+25.8%", positive: true }
                    ].map((stat, i) => (
                      <motion.div 
                        key={i} 
                        className="space-y-1 sm:space-y-2"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5 + i * 0.1 }}
                      >
                        <p className="text-[10px] sm:text-xs text-muted-foreground">{stat.label}</p>
                        <p className="text-sm sm:text-lg font-bold">{stat.value}</p>
                        <p className={`text-[10px] sm:text-xs font-medium ${stat.positive ? 'text-purple-600' : 'text-red-600'}`}>
                          {stat.change}
                        </p>
                      </motion.div>
                    ))}
                  </div>
                  <div className="h-24 sm:h-32 rounded-lg bg-gradient-to-r from-primary/10 to-violet-500/10 flex items-end justify-around p-2 sm:p-4 gap-1 sm:gap-2 overflow-hidden">
                    {[60, 80, 70, 90, 75, 95].map((height, i) => (
                      <motion.div
                        key={i}
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: `${height}%`, opacity: 1 }}
                        transition={{ duration: 0.8, delay: 0.6 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                        className="w-full max-w-8 bg-gradient-to-t from-primary via-violet-500 to-primary rounded-t shadow-lg"
                        whileHover={{ scale: 1.1 }}
                      />
                    ))}
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="recursos" className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
        <div className="max-w-7xl mx-auto relative">
          <motion.div 
            className="text-center space-y-4 mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold">
              Recursos <span className="bg-gradient-to-r from-primary to-violet-500 bg-clip-text text-transparent">poderosos</span> para sua empresa
            </h2>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto">
              Tudo que você precisa para gerenciar suas finanças de forma profissional
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {features.map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                viewport={{ once: true }}
                whileHover={{ y: -8 }}
              >
                <Card className="h-full hover:shadow-2xl hover:shadow-primary/10 transition-all duration-300 border-border/50 hover:border-primary/50 bg-card/50 backdrop-blur-sm group">
                  <CardContent className="p-6 space-y-4">
                    <motion.div 
                      className="h-14 w-14 rounded-xl bg-gradient-to-br from-primary to-violet-500 flex items-center justify-center shadow-lg shadow-primary/25"
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ type: "spring", stiffness: 400, damping: 10 }}
                    >
                      <feature.icon className="h-7 w-7 text-white" />
                    </motion.div>
                    <h3 className="text-xl font-semibold group-hover:text-primary transition-colors">{feature.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="preços" className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/3 to-background" />
        <div className="max-w-7xl mx-auto relative">
          <motion.div 
            className="text-center space-y-4 mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold">
              Planos para empresas de <span className="bg-gradient-to-r from-primary to-violet-500 bg-clip-text text-transparent">todos os tamanhos</span>
            </h2>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto">
              Escolha o plano ideal para o seu negócio
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 sm:gap-8">
            {plans.map((plan, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30, scale: plan.highlighted ? 1 : 0.95 }}
                whileInView={{ opacity: 1, y: 0, scale: plan.highlighted ? 1.05 : 1 }}
                transition={{ duration: 0.5, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                viewport={{ once: true }}
                whileHover={{ y: -8, scale: plan.highlighted ? 1.08 : 1.03 }}
              >
                <Card className={`h-full relative ${plan.highlighted ? 'border-2 border-primary shadow-2xl shadow-primary/20 bg-gradient-to-br from-primary/5 to-violet-500/5' : 'border-border/50 hover:border-primary/30'} transition-all duration-300`}>
                  {plan.highlighted && (
                    <motion.div 
                      className="absolute -top-5 left-1/2 -translate-x-1/2 px-4 py-1.5 rounded-full bg-gradient-to-r from-primary to-violet-500 text-white text-sm font-medium shadow-lg shadow-primary/50"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 400, damping: 15, delay: 0.5 + i * 0.1 }}
                    >
                      ⭐ Mais Popular
                    </motion.div>
                  )}
                  <CardContent className="p-8 space-y-6">
                    <div>
                      <h3 className="text-2xl font-bold">{plan.name}</h3>
                      <p className="text-sm text-muted-foreground mt-2">{plan.description}</p>
                    </div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      {plan.period && <span className="text-muted-foreground">{plan.period}</span>}
                    </div>
                    <Button 
                      className={`w-full ${plan.highlighted ? 'bg-gradient-to-r from-primary to-violet-500 hover:from-primary/90 hover:to-violet-600 shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30' : 'hover:bg-primary/5'} transition-all duration-300`}
                      variant={plan.highlighted ? 'default' : 'outline'}
                      onClick={() => setLocation('/register')}
                    >
                      {plan.highlighted ? 'Começar Agora' : 'Escolher Plano'}
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                    <div className="space-y-3 pt-6 border-t">
                      {plan.features.map((feature, idx) => (
                        <div key={idx} className="flex items-start gap-3">
                          <Check className="h-5 w-5 text-purple-600 flex-shrink-0 mt-0.5" />
                          <span className="text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="depoimentos" className="py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
        <div className="max-w-7xl mx-auto relative">
          <motion.div 
            className="text-center space-y-4 mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold">
              Confiado por <span className="bg-gradient-to-r from-primary to-violet-500 bg-clip-text text-transparent">empresas líderes</span>
            </h2>
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto">
              Veja o que nossos clientes dizem sobre nós
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {testimonials.map((testimonial, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                viewport={{ once: true }}
                whileHover={{ y: -8 }}
              >
                <Card className="h-full hover:shadow-2xl hover:shadow-primary/10 transition-all duration-300 border-border/50 hover:border-primary/30 bg-card/50 backdrop-blur-sm group">
                  <CardContent className="p-6 space-y-4">
                    <div className="flex gap-1">
                      {[...Array(testimonial.rating)].map((_, idx) => (
                        <motion.div
                          key={idx}
                          initial={{ scale: 0, rotate: -180 }}
                          animate={{ scale: 1, rotate: 0 }}
                          transition={{ type: "spring", stiffness: 300, damping: 20, delay: 0.5 + i * 0.1 + idx * 0.05 }}
                        >
                          <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                        </motion.div>
                      ))}
                    </div>
                    <p className="text-muted-foreground italic leading-relaxed">"{testimonial.content}"</p>
                    <div className="pt-4 border-t border-border/50">
                      <p className="font-semibold group-hover:text-primary transition-colors">{testimonial.name}</p>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            viewport={{ once: true }}
            className="relative rounded-3xl bg-gradient-to-r from-primary via-violet-500 to-primary p-8 sm:p-12 text-center text-white overflow-hidden shadow-2xl shadow-primary/25"
          >
            {/* Animated background patterns */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl animate-pulse" style={{ animationDuration: '4s' }} />
              <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl animate-pulse" style={{ animationDuration: '6s', animationDelay: '2s' }} />
            </div>
            
            <div className="relative z-10 space-y-6">
              <motion.h2 
                className="text-3xl sm:text-4xl lg:text-5xl font-bold"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                viewport={{ once: true }}
              >
                Pronto para transformar sua gestão financeira?
              </motion.h2>
              <motion.p 
                className="text-lg sm:text-xl opacity-95 max-w-2xl mx-auto leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                viewport={{ once: true }}
              >
                Junte-se a milhares de empresas que já otimizaram suas finanças com o LUCREI
              </motion.p>
              <motion.div 
                className="flex flex-col sm:flex-row gap-4 justify-center pt-4"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                viewport={{ once: true }}
              >
                <Button 
                  size="lg"
                  variant="secondary"
                  onClick={() => setLocation('/register')}
                  className="bg-white text-primary hover:bg-white/95 text-lg px-8 shadow-xl hover:scale-105 transition-all duration-300"
                >
                  Começar Agora Gratuitamente
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button 
                  size="lg"
                  variant="outline"
                  className="text-white border-2 border-white hover:bg-white/20 text-lg px-8 transition-all duration-300"
                >
                  Falar com Especialista
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="space-y-4">
              <div className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-violet-600 bg-clip-text text-transparent">
                LUCREI
              </div>
              <p className="text-sm text-muted-foreground">
                Gestão financeira inteligente para empresas modernas
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Produto</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="/recursos" className="hover:text-foreground transition-colors">Recursos</a></li>
                <li><a href="/pricing" className="hover:text-foreground transition-colors">Preços</a></li>
                <li><a href="/integracoes" className="hover:text-foreground transition-colors">Integrações</a></li>
                <li><a href="/api-docs" className="hover:text-foreground transition-colors">API</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Empresa</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="/sobre" className="hover:text-foreground transition-colors">Sobre</a></li>
                <li><a href="/blog" className="hover:text-foreground transition-colors">Blog</a></li>
                <li><a href="/carreiras" className="hover:text-foreground transition-colors">Carreiras</a></li>
                <li><a href="/contato" className="hover:text-foreground transition-colors">Contato</a></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="/privacidade" className="hover:text-foreground transition-colors">Privacidade</a></li>
                <li><a href="/termos" className="hover:text-foreground transition-colors">Termos</a></li>
                <li><a href="/seguranca" className="hover:text-foreground transition-colors">Segurança</a></li>
                <li><a href="/lgpd" className="hover:text-foreground transition-colors">LGPD</a></li>
              </ul>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t text-center text-sm text-muted-foreground">
            <p>© 2025 LUCREI. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
