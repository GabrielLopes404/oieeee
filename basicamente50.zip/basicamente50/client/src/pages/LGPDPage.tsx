import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Shield, Check } from "lucide-react";
import { motion } from "framer-motion";

export default function LGPDPage() {
  const [, setLocation] = useLocation();

  const rights = [
    "Confirmação da existência de tratamento de dados pessoais",
    "Acesso aos seus dados pessoais",
    "Correção de dados incompletos, inexatos ou desatualizados",
    "Anonimização, bloqueio ou eliminação de dados",
    "Portabilidade dos dados para outro fornecedor",
    "Eliminação dos dados tratados com seu consentimento",
    "Informação sobre compartilhamento de dados",
    "Revogação do consentimento a qualquer momento"
  ];

  const measures = [
    {
      title: "Minimização de Dados",
      description: "Coletamos apenas os dados estritamente necessários para fornecer nossos serviços."
    },
    {
      title: "Base Legal",
      description: "Todo tratamento de dados tem uma base legal clara: consentimento, execução de contrato ou legítimo interesse."
    },
    {
      title: "Transparência",
      description: "Você sempre sabe quais dados coletamos, por que coletamos e como os usamos."
    },
    {
      title: "Segurança",
      description: "Medidas técnicas e administrativas rigorosas para proteger seus dados contra acessos não autorizados."
    },
    {
      title: "DPO Dedicado",
      description: "Encarregado de Proteção de Dados disponível para responder suas questões sobre privacidade."
    },
    {
      title: "Resposta a Incidentes",
      description: "Procedimentos estabelecidos para identificar, reportar e mitigar incidentes de segurança."
    }
  ];

  return (
    <div className="dark min-h-screen bg-background text-foreground">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-full bg-gradient-to-r from-purple-600 to-purple-400 flex items-center justify-center">
              <Shield className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl sm:text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 to-purple-400 bg-clip-text text-transparent">
            Conformidade com LGPD
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            100% em conformidade com a Lei Geral de Proteção de Dados
          </p>
        </motion.div>

        <Card className="mb-8">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-4">Seus Direitos sob a LGPD</h2>
            <p className="text-muted-foreground mb-6">
              A Lei Geral de Proteção de Dados (Lei nº 13.709/2018) garante diversos direitos aos titulares de dados. 
              No LUCREI, você pode exercer todos esses direitos de forma simples e rápida:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {rights.map((right, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  className="flex items-start gap-3"
                >
                  <Check className="h-5 w-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <span className="text-sm">{right}</span>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-6 text-center">Medidas de Conformidade</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {measures.map((measure, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="h-full">
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-lg mb-2">{measure.title}</h3>
                    <p className="text-sm text-muted-foreground">{measure.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        <Card className="mb-8">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-4">Como Exercer Seus Direitos</h2>
            <p className="text-muted-foreground mb-4">
              Para exercer qualquer um dos seus direitos sob a LGPD, você pode:
            </p>
            <ul className="space-y-2 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-purple-600 font-bold">•</span>
                <span>Acessar as configurações da sua conta na plataforma</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-purple-600 font-bold">•</span>
                <span>Enviar um email para nosso DPO: dpo@lucrei.app</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-purple-600 font-bold">•</span>
                <span>Entrar em contato através do nosso formulário de contato</span>
              </li>
            </ul>
            <p className="text-sm text-muted-foreground mt-4">
              Respondemos todas as solicitações em até 15 dias úteis, conforme estabelecido pela LGPD.
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500/10 to-purple-600/10 border-purple-500/20">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Fale com nosso DPO</h2>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Nosso Encarregado de Proteção de Dados está disponível para esclarecer qualquer 
              dúvida sobre tratamento de dados pessoais.
            </p>
            <div className="flex gap-4 justify-center">
              <Button 
                variant="outline"
                onClick={() => window.location.href = "mailto:dpo@lucrei.app"}
              >
                dpo@lucrei.app
              </Button>
              <Button 
                onClick={() => setLocation("/contato")}
                className="bg-gradient-to-r from-purple-600 to-purple-400"
              >
                Formulário de Contato
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
